<?php $__env->startSection('main-sec'); ?>
    <!-- Header-background-markup -->
    <div class="overlay-bg relative">
        <img src="<?php echo e(asset('assets-chance-website/images/slide/silder-1 (2).jpeg')); ?>" alt="">
    </div>
    <!-- Header-jumbotron -->
    <div class="space-100"></div>
    <div class="header-text">
        <div class="container">
            <div class="row wow fadeInUp">
                <div class="col-xs-12 col-sm-10 col-sm-offset-1 text-center">
                    <div class="jumbotron">
                        <h1 class="text-white">Chance Digital Library To Save Your Time</h1>
                    </div>
                    <div class="title-bar white">
                        <ul class="list-inline list-unstyled">
                            <li><i class="icofont icofont-square"></i></li>
                            <li><i class="icofont icofont-square"></i></li>
                        </ul>
                    </div>
                    <div class="space-40"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="space-100"></div>
    <!-- Header-jumbotron-end -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="space-80"></div>
        <div class="container">
            <div class="row"> <!-- Parent row -->
                <!-- Sidebar -->
                <div class="col-xs-12 col-md-2">
                    <aside id="droplist">
                        <h3><i class="icofont icofont-filter"></i> Filter By</h3>
                        <div class="space-30"></div>
                        <div class="sigle-sidebar">
                            <h4>Category</h4>
                            <hr>
                            <ul class="list-unstyled menu-tip">
                                <li>
                                    <button
                                        onclick="window.location.href='<?php echo e(route('search.result.filter.all', ['category', 'all'])); ?>'">
                                        All category
                                    </button>
                                </li>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <button
                                            onclick="window.location.href='<?php echo e(route('search.result.filterID', ['category', $category->id])); ?>'">
                                            <?php echo e($category->category_name); ?>

                                        </button>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="space-20"></div>
                        <div class="space-30"></div>
                        <div class="sigle-sidebar">
                            <h4>Department</h4>
                            <hr>
                            <ul class="list-unstyled menu-tip">
                                <li>
                                    <button
                                        onclick="window.location.href='<?php echo e(route('search.result.filter.all', ['department', 'all'])); ?>'">
                                        All department
                                    </button>
                                </li>
                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <button
                                            onclick="window.location.href='<?php echo e(route('search.result.filterID', ['department', $department->id])); ?>'">
                                            <?php echo e($department->department_name); ?>

                                        </button>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="space-20"></div>
                        <div class="space-30"></div>
                        <div class="sigle-sidebar">
                            <h4>Professor</h4>
                            <hr>
                            <ul class="list-unstyled menu-tip">
                                <li>
                                    <button
                                        onclick="window.location.href='<?php echo e(route('search.result.filter.all', ['professor', 'all'])); ?>'">
                                        All professor
                                    </button>
                                </li>
                                <?php $__currentLoopData = $professors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $professor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <button
                                            onclick="window.location.href='<?php echo e(route('search.result.filterID', ['professor', $professor->id])); ?>'">
                                            <?php echo e($professor->professor_name); ?>

                                        </button>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        
                        <div class="space-20"></div>
                    </aside>
                </div>
                <!-- end Sidebar-->

                <!-- Content -->
                <div class="col-xs-12 col-md-10 pull-right">
                    <h4>Search Box</h4>
                    <div class="space-5"></div>
                    <form action="<?php echo e(route('search.result')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="input-group">
                            <input type="text" name="query" class="form-control"
                                placeholder="Enter what you are looking for">
                            <div class="input-group-btn">
                                <button type="submit" class="btn btn-primary"><i
                                        class="icofont icofont-search-alt-2"></i></button>
                            </div>
                        </div>
                    </form>
                    <div class="space-30"></div>
                    
                    
                    
                    <div class="space-30"></div>
                    <hr>
                    <div class="space-20"></div>

                    <!-- Content including the loop -->
                    <div style="display: flex;flex-wrap: wrap;">
                        <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xs-12 col-md-4 filter-items" id="display_content" data-Allcategory="Allcategory"
                                data-Alldepartment="Alldepartment" data-Allprofessor="Allprofessor"
                                data-department="<?php echo e($material->subject->department->department_name); ?>"
                                data-category="<?php echo e($material->subject->category->category_name); ?>"
                                data-professor="<?php echo e(optional($material->subject->professor)->professor_name ?? 'N/A'); ?>">
                                <div class="category-item well yellow">
                                    <div class="media">
                                        <div class="media-body" style="display: flex;">
                                            
                                            <div>
                                                <h5 style="font-weight: bold;"><?php echo e($material->subject->subject_name); ?></h5>
                                                <h6>Department: <?php echo e($material->subject->department->department_name); ?></h6>
                                                <h6>Category: <?php echo e($material->subject->category->category_name); ?></h6>
                                                <?php if($material->subject && $material->subject->professor): ?>
                                                    <h6>Professor: <?php echo e($material->subject->professor->professor_name); ?></h6>
                                                <?php else: ?>
                                                    <h6>Professor: No Professor available</h6>
                                                <?php endif; ?>
                                                <h6>Pdf: <?php echo e($material->pdf_file_name); ?></h6>
                                            </div>
                                        </div>
                                        <div style="display: flex;align-items: center;flex-wrap: wrap;">
                                            <a href="<?php echo e($material->pdf_file_download); ?> " target="blank"
                                                class="btn btn-outline-primary">
                                                <i class="fas fa-download"></i> Download
                                            </a>
                                            <button
                                                data-pdf-link="
                                             <?php echo e($material->pdf_file_link); ?>

                                                "
                                                class="btn btn-outline-primary view-button">
                                                <i class="fas fa-eye"></i> View
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- End loop -->
                    <?php echo $__env->make('ChanceWebsite.include.pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div id="file-popup" class="file-popup">
                        <iframe id="file-viewer" class="file-viewer" name="file-viewer"></iframe>
                        <button id="close-button" class="close-button">Close</button>
                    </div>

                    <!--end content-->
                    <div class="space-60"></div>
                </div>
            </div> <!-- End parent row -->
        </div>
        <div class="space-80"></div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ChanceWebsite.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd5/707/21354707/resources/views/ChanceWebsite/pages/Search/Search.blade.php ENDPATH**/ ?>