<!-- Mainmenu-markup-start -->
<div class="mainmenu-area navbar-fixed-top" data-spy="affix" data-offset-top="10">
    <nav class="navbar">
        <div class="container">
            <div class="navbar-header">
                <div class="space-10"></div>
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainmenu">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!--Logo-->
                <div>
                    <a href="<?php echo e(route('Home.index')); ?>" class="navbar-left show"><img
                            src="<?php echo e(asset('public-images/Chance-logo.png')); ?>"style="width: 6em;height: 3em;"
                            alt="chance logo"></a>
                    <div class="space-10"></div>
                </div>
            </div>
            <!--Toggle-button-->

            <!--Mainmenu list-->
            <div class="navbar-right in fade" id="mainmenu">
                <ul class="nav navbar-nav nav-white text-uppercase">
                    <li >
                        <a href="<?php echo e(route('Home.index')); ?>">Home</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('search')); ?>">Matirals</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.dashboard.checklogin')); ?>">Admin Login</a>
                    </li>
                    
                </ul>
            </div>
        </div>
    </nav>
</div>
<div class="space-100"></div>
<?php /**PATH /storage/ssd5/707/21354707/resources/views/ChanceWebsite/include/nav.blade.php ENDPATH**/ ?>