<link rel="stylesheet" href="<?php echo e(asset('assets/css/loader.css')); ?>">
<section id="loading">
<div class="loading-container">
  <div class="loading-text">
    <span>C</span>
    <span>H</span>
    <span>A</span>
    <span>N</span>
    <span>C</span>
    <span>E</span>
  </div>
</div>
</section>



<script src="<?php echo e(asset('assets/js/onload.js')); ?>"></script>
<?php /**PATH D:\github\chance-library-2\chance-libary-3\resources\views/ChanceWebsite/include/loader.blade.php ENDPATH**/ ?>