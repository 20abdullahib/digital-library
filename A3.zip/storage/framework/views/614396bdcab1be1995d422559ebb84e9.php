<div class="ml-2">
    <nav aria-label="...">
        <ul class="pagination">
            <li class="page-item <?php echo e($materials->currentPage() == 1 ? 'disabled' : ''); ?>">
                <a class="page-link" href="<?php echo e($materials->previousPageUrl()); ?>">Previous</a>
            </li>
            <?php for($i = 1; $i <= $materials->lastPage(); $i++): ?>
                <li class="page-item <?php echo e($materials->currentPage() == $i ? 'active' : ''); ?>">
                    <a class="page-link" href="<?php echo e($materials->url($i)); ?>"><?php echo e($i); ?></a>
                </li>
            <?php endfor; ?>
            <li class="page-item <?php echo e($materials->currentPage() == $materials->lastPage() ? 'disabled' : ''); ?>">
                <a class="page-link" href="<?php echo e($materials->nextPageUrl()); ?>">Next</a>
            </li>
        </ul>
    </nav>

    <!-- Display current page and total pages -->
    <div class="pagination-info ml-2">
        Page <?php echo e($materials->currentPage()); ?> of <?php echo e($materials->lastPage()); ?>

    </div>
</div>
</div>
<?php /**PATH /storage/ssd5/707/21354707/resources/views/ChanceWebsite/include/pagination.blade.php ENDPATH**/ ?>