<?php $__env->startSection('content'); ?>
    <!-- Page Content  -->
    
    <div class="main-content">
        <?php echo $__env->make('Dashboard.include.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="card card-stats">
                    <div class="card-header">
                        <div class="icon icon-warning">
                            <i class="material-icons">manage_accounts</i>
                        </div>
                    </div>
                    <div class="card-content">
                        <p class="category"><strong>Admins</strong></p>
                        <h3 class="card-title"><?php echo e(count($Admins)); ?></h3>
                    </div>
                    
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="card card-stats">
                    <div class="card-header">
                        <div class="icon icon-rose">
                            <span class="material-icons">
                                description
                            </span>
                        </div>
                    </div>
                    <div class="card-content">
                        <p class="category"><strong>files</strong></p>
                        <h3 class="card-title"><?php echo e(count($materials)); ?></h3>
                    </div>
                    

                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="card card-stats">
                    <div class="card-header">
                        <div class="icon icon-success">
                            <span class="material-icons"> people </span>
                        </div>
                    </div>
                    <div class="card-content">
                        <p class="category"><strong>Users</strong></p>
                        <h3 class="card-title">???</h3>
                    </div>
                    
                </div>
            </div>
            
        </div>

        <div class="row">
            <div class="col-lg-7 col-md-12" style="font-size: medium;">
                <div class="card" style="min-height: 485px">
                    <div class="card-header card-header-text">
                        <h4 class="card-title">Chance Stats</h4>
                        
                    </div>
                    <div class="card-content table-responsive ">
                        <table class="table table-hover text-center">
                            <thead class="text-primary">
                                <tr>
                                    <th>Admin ID</th>
                                    <th>Name</th>
                                    <th>Rank</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($Admin->admin_id); ?></td>
                                        <td><?php echo e($Admin->name); ?></td>
                                        <td><?php echo e($Admin->rank); ?></td>
                                        <td>
                                            

                                            <form action="<?php echo e(route('admin.destroy', $Admin->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-lg-5 col-md-12">
                <div class="card" style="min-height: 485px">
                    <div class="card-header card-header-text">
                        <h4 class="card-title">Activities</h4>
                    </div>
                    <div class="card-content">
                        <div class="streamline">
                            <div class="sl-item sl-primary">
                                <div class="sl-content">
                                    <small class="text-muted">5 mins ago</small>
                                    <p>Williams has just joined Project X</p>
                                </div>
                            </div>
                            <div class="sl-item sl-danger">
                                <div class="sl-content">
                                    <small class="text-muted">25 mins ago</small>
                                    <p>
                                        Jane has sent a request for access to the project
                                        folder
                                    </p>
                                </div>
                            </div>
                            <div class="sl-item sl-success">
                                <div class="sl-content">
                                    <small class="text-muted">40 mins ago</small>
                                    <p>Kate added you to her team</p>
                                </div>
                            </div>
                            <div class="sl-item">
                                <div class="sl-content">
                                    <small class="text-muted">45 minutes ago</small>
                                    <p>John has finished his task</p>
                                </div>
                            </div>
                            <div class="sl-item sl-warning">
                                <div class="sl-content">
                                    <small class="text-muted">55 mins ago</small>
                                    <p>Jim shared a folder with you</p>
                                </div>
                            </div>
                            <div class="sl-item">
                                <div class="sl-content">
                                    <small class="text-muted">60 minutes ago</small>
                                    <p>John has finished his task</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard.layout.Dashboard_Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abdullah\Desktop\project\magic-site\chance_up_2_13_2024\resources\views/Dashboard/Home_Dashboard.blade.php ENDPATH**/ ?>