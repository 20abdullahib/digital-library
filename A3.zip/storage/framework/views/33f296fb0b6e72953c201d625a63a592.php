<?php $__env->startSection('content'); ?>
    <div style="overflow: auto;">
        <?php echo $__env->make('Dashboard.include.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action="<?php echo e(route('subject.search')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="input-group mb-3">
                <input type="text" class="form-control" name="search" placeholder="Search...">
                <div class="input-group-append">
                    <button class="btn btn-outline-secondary" type="submit">Search</button>
                    <button class="btn btn-outline-secondary" type="btn"><a href="<?php echo e(route("subject.index")); ?>">All subject</a></button>
                </div>
            </div>
        </form>
        

        <table class="table table-hover text-center table-bordered">
            <thead class="text-primary">
                <tr>
                    <th>Subject Name</th>
                    <th>Academic Subject code</th>
                    <th>Department</th>
                    <th>Category</th>
                    <th>Professor</th>
                    
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        

                        <form id="deleteForm<?php echo e($subject->id); ?>" action="<?php echo e(route('subject.destroy', $subject->id)); ?>"
                            method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                        </form>

                        <form action="<?php echo e(route('subject.update', $subject->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <td class="editable" onclick="makeEditable(this)">
                                <span><?php echo e($subject->subject_name); ?></span>
                                <input type="text" value="<?php echo e($subject->subject_name); ?>" name="subject_name">
                            </td>

                            <td class="editable" onclick="makeEditable(this)">
                                <span><?php echo e($subject->academic_subject_code); ?></span>
                                <input type="text" value="<?php echo e($subject->academic_subject_code); ?>"
                                    name="academic_subject_code">
                            </td>

                            <td>
                                <div class="select-container">
                                    <select name="department_id" class="select-styled">
                                        <option value="" disabled selected><?php echo e($subject->department->department_name); ?>

                                        </option>
                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($department->id); ?>">
                                                <?php echo e($department->department_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </td>

                            <td>
                                <div class="select-container">
                                    <select name="category_id" class="select-styled">
                                        <option value="" disabled selected><?php echo e($subject->category->category_name); ?>

                                        </option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </td>

                            <td>
                                <div class="select-container">
                                    <!--<select name="professor_id" class="select-styled">-->
                                    <!--    <option value="" disabled selected>-->
                                    <!--    </option>-->
                                    <!--    <?php $__currentLoopData = $professors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $professor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
                                    <!--        <option value="">-->
                                    <!--            </option>-->
                                    <!--    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
                                    <!--</select>-->
                                    
                                <select name="professor_id" class="select-styled">
                                    <?php if($subject->professor): ?>
                                        <option value="<?php echo e($subject->professor->id); ?>" selected>
                                            <?php echo e($subject->professor->professor_name); ?>

                                        </option>
                                    <?php else: ?>
                                        <option value="" disabled selected>Select Professor</option>
                                    <?php endif; ?>
                                
                                    <?php $__currentLoopData = $professors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $professor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($professor->id); ?>">
                                            <?php echo e($professor->professor_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                </div>
                            </td>

                            <td>
                                
                                    <a class="btn btn-info show-btn" href="<?php echo e(route('subject.show', $subject->id)); ?>">Show</a>
                                <button class="btn btn-warning update-btn"
                                    data-subject-id="<?php echo e($subject->id); ?>">Update</button>
                                <button type="button" class="btn btn-danger"
                                    onclick="activateDeleteForm(<?php echo e($subject->id); ?>)">Delete</button>
                            </td>
                        </form>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
        <?php echo $__env->make('Dashboard.include.pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard.layout.Dashboard_Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abdullah\Desktop\project\magic-site\chance_up_2_13_2024\resources\views/Dashboard/pages/Subject/All_Subject.blade.php ENDPATH**/ ?>