 <!----css---->
 <link rel="stylesheet" href="<?php echo e(asset('assets-dashboard/css/bootstrap.min.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('assets-dashboard/css/custom.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('assets-dashboard/css/style.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('assets-dashboard/css/form.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('assets-dashboard/css/loader.css')); ?>" />
 <link rel="shortcut icon" type="ico" href="<?php echo e(asset("public-images\Magic-logo.png")); ?>">


 <!-- SLIDER  -->
 <link rel="preconnect" href="https://fonts.googleapis.com" />
 <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
 <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet" />
 <!--google material icon-->
 <link href="https://fonts.googleapis.com/css2?family=Material+Icons" rel="stylesheet" />


<?php /**PATH C:\Users\abdullah\Desktop\project\magic-site\chance_up_2_13_2024\resources\views/Dashboard/include/Head_Dashboard.blade.php ENDPATH**/ ?>