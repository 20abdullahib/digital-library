<aside>
    <div class="body-overlay"></div>
    <nav id="sidebar">
        <div class="sidebar-header">
            <img src="<?php echo e(asset('public-images/Chance-logo.png')); ?>" style="width: 8em;height: fit-content;" />
        </div>
        <ul class="list-unstyled components">
            <li>
                <a href="<?php echo e(route('admin.index')); ?>" class="dashboard"><i
                        class="material-icons">dashboard</i><span>Dashboard</span></a>
            </li>

            <li class="dropdown">
                <a href="#homeSubmenu1" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                    <i class="material-icons">supervisor_account</i><span>Admin</span></a>
                <ul class="collapse list-unstyled menu" id="homeSubmenu1">
                    <li>
                        <a href="<?php echo e(route('admin.create')); ?>">Add Admin</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('dashboard.show-admins')); ?>">All Admins</a>
                    </li>
                </ul>
            </li>

            <li class="dropdown">
                <a href="#pageSubmenu2" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                    <i class="material-icons">book</i><span>Subjects</span></a>
                <ul class="collapse list-unstyled menu" id="pageSubmenu2">
                    <li>
                        <a href="<?php echo e(route('subject.index')); ?>">All Subjects</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('subject.create')); ?>">Add Subjects</a>
                    </li>
                </ul>
            </li>

            
        </ul>
    </nav>
</aside>
<?php /**PATH /storage/ssd5/707/21354707/resources/views/Dashboard/include/Sidebar_Dashboard.blade.php ENDPATH**/ ?>