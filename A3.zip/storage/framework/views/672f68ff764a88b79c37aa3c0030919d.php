<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('Dashboard.include.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div>
        <table class="table table-hover text-center">
            <thead class="text-primary">
                <tr>
                    <th>Admin ID</th>
                    <th>Name</th>
                    <th>Rank</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $Admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($Admin->admin_id); ?></td>
                        <td><?php echo e($Admin->name); ?></td>
                        <td><?php echo e($Admin->rank); ?></td>
                        <td>
                            <form action="<?php echo e(route('admin.destroy', $Admin->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard.layout.Dashboard_Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd5/707/21354707/resources/views/Dashboard/pages/Admin/Show_Admins.blade.php ENDPATH**/ ?>