<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('ChanceWebsite.include.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('ChanceWebsite.include.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section id="content">
        <header class="relative" id="sc1">
            <?php echo $__env->yieldContent('Header-background'); ?>
            <?php echo $__env->make('ChanceWebsite.include.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('main-sec'); ?>
        </header>
        <section>
            <?php echo $__env->yieldContent('content'); ?>
        </section>
        <?php echo $__env->make('ChanceWebsite.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('ChanceWebsite.include.js_scripte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>
</body>

</html>
<?php /**PATH C:\Users\abdullah\Desktop\project\magic-site\chance_up_2_13_2024\resources\views/ChanceWebsite/layout/layout.blade.php ENDPATH**/ ?>