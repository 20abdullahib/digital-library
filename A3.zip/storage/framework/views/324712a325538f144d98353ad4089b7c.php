
<section id="loading">
  <div class="loading-container">
  
    <div class="classic-3"></div>
    
  </div>
</section>




<?php /**PATH C:\Users\abdullah\Desktop\project\magic-site\chance_up_2_13_2024\resources\views/Dashboard/include/loader.blade.php ENDPATH**/ ?>