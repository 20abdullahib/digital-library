<div class="ml-2">
    <nav aria-label="...">
        <ul class="pagination">
            <li class="page-item <?php echo e($subjects->currentPage() == 1 ? 'disabled' : ''); ?>">
                <a class="page-link" href="<?php echo e($subjects->previousPageUrl()); ?>">Previous</a>
            </li>
            <?php for($i = 1; $i <= $subjects->lastPage(); $i++): ?>
                <li class="page-item <?php echo e($subjects->currentPage() == $i ? 'active' : ''); ?>">
                    <a class="page-link" href="<?php echo e($subjects->url($i)); ?>"><?php echo e($i); ?></a>
                </li>
            <?php endfor; ?>
            <li class="page-item <?php echo e($subjects->currentPage() == $subjects->lastPage() ? 'disabled' : ''); ?>">
                <a class="page-link" href="<?php echo e($subjects->nextPageUrl()); ?>">Next</a>
            </li>
        </ul>
    </nav>

    <!-- Display current page and total pages -->
    <div class="pagination-info ml-2">
        Page <?php echo e($subjects->currentPage()); ?> of <?php echo e($subjects->lastPage()); ?>

    </div>
</div>
</div>
<?php /**PATH C:\Users\abdullah\Desktop\project\magic-site\chance_up_2_13_2024\resources\views/Dashboard/include/pagination.blade.php ENDPATH**/ ?>