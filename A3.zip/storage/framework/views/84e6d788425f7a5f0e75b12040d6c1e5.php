<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>chance dashboard</title>
    <?php echo $__env->make('Dashboard.include.Head_Dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('Dashboard.include.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section id="content" class="wrapper">
        <?php echo $__env->make('Dashboard.include.Sidebar_Dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section id="content-dashboard" style="overflow:auto;">
            <?php echo $__env->make('Dashboard.include.Top_Tavbar_Dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div style='overflow:auto;'>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </section>
    </section>
    <?php echo $__env->make('Dashboard.include.Script_Dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\abdullah\Desktop\project\magic-site\chance_up_2_13_2024\resources\views/Dashboard/layout/Dashboard_Layout.blade.php ENDPATH**/ ?>