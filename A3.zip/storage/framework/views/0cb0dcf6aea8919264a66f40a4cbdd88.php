<!-- Vendor-JS -->
<script src="<?php echo e(asset('assets-chance-website/js/vendor/jquery-1.12.4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets-chance-website/js/vendor/bootstrap.min.js')); ?>"></script>
<!-- Plugin-JS -->
<script src="<?php echo e(asset('assets-chance-website/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets-chance-website/js/responsiveslides.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets-chance-website/js/jquery.cardslider.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets-chance-website/js/pagination.js')); ?>"></script>
<script src="<?php echo e(asset('assets-chance-website/js/scrollUp.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets-chance-website/js/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets-chance-website/js/plugins.js')); ?>"></script>
<!-- Active-JS -->
<script src="<?php echo e(asset('assets-chance-website/js/main.js')); ?>"></script>

<script src="<?php echo e(asset('assets-chance-website/js/onload.js')); ?>"></script>

<script src="<?php echo e(asset('assets-chance-website/js/active-nav.js')); ?>"></script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="<?php echo e(asset('assets-chance-website/js/filter_display.js')); ?>"></script>

<script src="<?php echo e(asset('assets-chance-website/js/minPriview.js')); ?>"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/viewerjs/1.9.3/viewer.min.js"></script>




<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->




<?php /**PATH D:\github\chance-library-2\chance-libary-3\resources\views/ChanceWebsite/include/js_scripte.blade.php ENDPATH**/ ?>