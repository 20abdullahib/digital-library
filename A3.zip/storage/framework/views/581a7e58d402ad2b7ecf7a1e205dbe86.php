 <!----css---->
 <link rel="stylesheet" href="<?php echo e(asset('assets-dashboard/css/bootstrap.min.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('assets-dashboard/css/custom.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('assets-dashboard/css/style.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('assets-dashboard/css/form.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('assets-dashboard/css/loader.css')); ?>" />


 <!-- SLIDER  -->
 <link rel="preconnect" href="https://fonts.googleapis.com" />
 <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
 <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet" />
 <!--google material icon-->
 <link href="https://fonts.googleapis.com/css2?family=Material+Icons" rel="stylesheet" />


<?php /**PATH /storage/ssd5/707/21354707/resources/views/Dashboard/include/Head_Dashboard.blade.php ENDPATH**/ ?>