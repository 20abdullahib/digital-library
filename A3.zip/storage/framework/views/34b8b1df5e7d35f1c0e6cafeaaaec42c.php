<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('errors')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('errors')); ?>

    </div>
<?php endif; ?>

<?php /**PATH /storage/ssd5/707/21354707/resources/views/Dashboard/include/success.blade.php ENDPATH**/ ?>