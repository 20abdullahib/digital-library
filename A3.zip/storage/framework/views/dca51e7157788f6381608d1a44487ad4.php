<!-- login-style -->
<link rel="stylesheet" href="<?php echo e(asset('assets-login/login_page.min.css')); ?>">
<?php $__env->startSection('content'); ?>
    <div id="login_page">
        <div class="login_page_wrapper">
            <div class="md-card" id="login_card">
                <div class="md-card-content large-padding" id="login_form">
                    <div class="login_heading">
                        <h2>Magic Admin Login</h2>
                    </div>
                    <form method="post" action="<?php echo e(route('admin.dashboard.checklogin')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="uk-form-row">
                            <label for="login_username">Email</label>
                            <input class="md-input" type="text" id="login_username" name="email" />
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback text-danger" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="uk-form-row">
                            <label for="login_password">Password</label>
                            <input class="md-input" type="password" id="login_password" name="password" />
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback text-danger" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="uk-margin-medium-top">
                            <input type="submit" value="Sign In" class="md-btn md-btn-primary md-btn-block md-btn-large" />
                        </div>

                    </form>
                </div>
                
            </div>

            
            <div class="uk-margin-top uk-text-center">
                <a href="<?php echo e(route('Home.index')); ?>">Home</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ChanceWebsite.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abdullah\Desktop\project\magic-site\chance_up_2_13_2024\resources\views/ChanceWebsite/auth/login.blade.php ENDPATH**/ ?>