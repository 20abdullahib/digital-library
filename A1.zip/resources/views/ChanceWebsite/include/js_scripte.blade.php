{{-- footer --}}
<script src="{{asset("assets-chance-website/js/footer.js")}}"></script>
<!-- Vendor-JS -->
<script src="{{ asset('assets-chance-website/js/vendor/jquery-1.12.4.min.js') }}"></script>
<script src="{{ asset('assets-chance-website/js/vendor/bootstrap.min.js') }}"></script>
<!-- Plugin-JS -->
<script src="{{ asset('assets-chance-website/js/owl.carousel.min.js') }}"></script>
<script src="{{ asset('assets-chance-website/js/responsiveslides.min.js') }}"></script>
<script src="{{ asset('assets-chance-website/js/jquery.cardslider.min.js') }}"></script>
<script src="{{ asset('assets-chance-website/js/pagination.js') }}"></script>
<script src="{{ asset('assets-chance-website/js/scrollUp.min.js') }}"></script>
<script src="{{ asset('assets-chance-website/js/wow.min.js') }}"></script>
<script src="{{ asset('assets-chance-website/js/plugins.js') }}"></script>
<!-- Active-JS -->
<script src="{{ asset('assets-chance-website/js/main.js') }}"></script>
{{-- onload --}}
<script src="{{ asset('assets-chance-website/js/onload.js') }}"></script>
{{-- active link --}}
<script src="{{ asset('assets-chance-website/js/active-nav.js') }}"></script>
{{-- filter display --}}
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="{{ asset('assets-chance-website/js/filter_display.js') }}"></script>

{{-- min-Priview --}}
<script src="{{ asset('assets-chance-website/js/minPriview.js') }}"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/viewerjs/1.9.3/viewer.min.js"></script>

<!-- MDB -->
<script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.umd.min.js"
></script>


{{-- dashboard-js --}}

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->

{{-- <script src="{{asset('assets-chance-website-dashboard/js/jquery-3.3.1.slim.min.js')}}"></script>
<script src="{{asset('assets-chance-website-dashboard/js/popper.min.js')}}"></script>
<script src="{{asset('assets-chance-website-dashboard/js/bootstrap.min.js')}}"></script>
<script src="{{asset('assets-chance-website-dashboard/js/jquery-3.3.1.min.js')}}"></script>
<script src="{{asset('assets-chance-website-dashboard/js/jquery.js')}}"></script>
<script src="{{asset('assets-chance-website-dashboard/js/main.js')}}"></script> --}}


