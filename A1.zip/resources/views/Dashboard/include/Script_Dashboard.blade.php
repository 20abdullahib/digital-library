<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="{{ asset('assets-dashboard/js/jquery-3.3.1.slim.min.js') }}"></script>
<script src="{{ asset('assets-dashboard/js/popper.min.js') }}"></script>
<script src="{{ asset('assets-dashboard/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('assets-dashboard/js/jquery-3.3.1.min.js') }}"></script>
<script src="{{ asset('assets-dashboard/js/jquery.js') }}"></script>
<script src="{{ asset('assets-dashboard/js/main.js') }}"></script>

<script src="{{ asset('assets-dashboard/js/onload.js') }}"></script>


<!--<script src="{{ asset('assets-dashboard/js/handel.js') }}"></script>-->


<script src="{{ asset('assets-dashboard/js/active-nav.js') }}"></script>


<script src="{{ asset('assets-dashboard/js/makeEditeTable.js') }}"></script>

<script src="{{ asset('assets-dashboard/js/selectStyle.js') }}"></script>


