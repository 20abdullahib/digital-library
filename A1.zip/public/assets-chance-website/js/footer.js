// Function to open the custom modal
function openModal() {
    var modal = document.getElementById("customModal");
    modal.style.display = "block";
}

// Function to close the custom modal
function closeModal() {
    var modal = document.getElementById("customModal");
    modal.style.display = "none";
}

